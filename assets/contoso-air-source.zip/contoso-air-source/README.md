# DevOps Challenge for GitHub and Azure

This repo contains the source code for the DevOps Challenge.